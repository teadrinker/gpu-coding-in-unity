﻿using UnityEngine;
using System.Collections;

public class InstantiatePrefabs : MonoBehaviour {

	public GameObject prefab;
	public int count = 1000;

	void Start() {
		for (int i = 0; i < count; i++) {
			Instantiate(prefab, Vector3.zero, Quaternion.identity);
		}
	} 

}
