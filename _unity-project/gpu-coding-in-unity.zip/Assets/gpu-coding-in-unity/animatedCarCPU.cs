using UnityEngine;
using System.Collections;

[ExecuteInEditMode]


public class animatedCarCPU : MonoBehaviour {

	Mesh CreateQuadMesh(float sizeX, float sizeU, float sizeV, int offsetU, int offsetV)
	{
		Mesh m = new Mesh();
		m.name = "QuadMesh";

		Vector3[] verts = new Vector3[4];
		Vector2[] uv    = new Vector2[4];
		int[]     tris  = new int[2 * 3];

		float aspect =  sizeV / sizeU;
		float vertSizeX = sizeX * 0.5f;
		float vertSizeY = sizeX * 0.5f * aspect;
		float u1 = sizeU * offsetU;
		float u2 = sizeU * (offsetU + 1.0f);
		float v1 = sizeV * offsetV;
		float v2 = sizeV * (offsetV + 1.0f);

		verts[0] = new Vector3(-vertSizeX, -vertSizeY,  0.0f);
		uv   [0] = new Vector2( u1,  v1);
		verts[1] = new Vector3( vertSizeX, -vertSizeY , 0.0f);
		uv   [1] = new Vector2( u2,  v1);
		verts[2] = new Vector3( vertSizeX,  vertSizeY , 0.0f);
		uv   [2] = new Vector2( u2,  v2);
		verts[3] = new Vector3(-vertSizeX,  vertSizeY , 0.0f);
		uv   [3] = new Vector2( u1,  v2);
		tris [0] = 0;
		tris [1] = 2;
		tris [2] = 1;
		tris [3] = 0;
		tris [4] = 3;
		tris [5] = 2;

		m.vertices = verts;
		m.uv = uv;
		m.triangles = tris;

		m.RecalculateNormals();

		return m;
	}


	public float speed = 2.4f;
	public float speedVariation = 0.36f;
	public float width = 400.0f;
	public float depth = 250.0f;

	float currentPosX = 250.0f;
	float currentPosZ = 0;
	float currentSpeed = 1;


	void Start () {

		if (gameObject.GetComponent<MeshFilter> ()) { DestroyImmediate (gameObject.GetComponent<MeshFilter> ()); }

		MeshFilter meshFilter = (MeshFilter)gameObject.AddComponent(typeof(MeshFilter));

		meshFilter.mesh = CreateQuadMesh(
			4.5f,  // car should be around 4 meters
			0.1914063f, 0.08691406f, // the size of each sprite, UV coordinate space 
			Random.Range(0,5), Random.Range(0,10) // randomize car sprite
		);

		currentPosZ = Random.value * depth; // randomize depth value
		currentSpeed = speed * (1.0f - speedVariation * Random.value); // initialize the speed for this car
		currentPosX = (Random.value - 0.5f) * width; // initialize position for this car
	}
			
	void Update () { 
		currentPosX += currentSpeed * Time.deltaTime;
		if(currentPosX > width/2) {
			currentPosX = -width/2;
		}

		transform.localPosition = new Vector3(currentPosX, 0.0f, currentPosZ);
	}


}
