﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]

public class generateQuads : MonoBehaviour {
	
	public int count = 1;


#if UNITY_EDITOR


	float o_count;


	Mesh CreateSpriteMeshes(int count)
	{
		Mesh m = new Mesh();
		m.name = "QuadsMesh";

		Vector3[] verts = new Vector3[count * 4];
		Vector2[] uv    = new Vector2[count * 4];
		int[]     tris  = new int[count * 2 * 3];
		 
		for (int i = 0; i < count; i++) {
			float fi = 1.0f - (((float)i + 1.0f) / ((float)count));
			verts[ i*4 + 0] = new Vector3(-0.5f, -0.5f, fi);
			uv   [ i*4 + 0] = new Vector2( 0.0f,  0.0f);
			verts[ i*4 + 1] = new Vector3( 0.5f, -0.5f , fi);
			uv   [ i*4 + 1] = new Vector2( 1.0f,  0.0f);
			verts[ i*4 + 2] = new Vector3( 0.5f,  0.5f , fi);
			uv   [ i*4 + 2] = new Vector2( 1.0f,  1.0f);
			verts[ i*4 + 3] = new Vector3(-0.5f,  0.5f , fi);
			uv   [ i*4 + 3] = new Vector2( 0.0f,  1.0f);
			tris [ i*6 + 0] = i*4 + 0;
			tris [ i*6 + 1] = i*4 + 2;
			tris [ i*6 + 2] = i*4 + 1;
			tris [ i*6 + 3] = i*4 + 0;
			tris [ i*6 + 4] = i*4 + 3;
			tris [ i*6 + 5] = i*4 + 2;
		}

		m.vertices = verts;
		m.uv = uv;
		m.triangles = tris;

		m.RecalculateNormals();

	//	m.bounds.center.x = 0.0;
	//	m.bounds.center.y = 0.0;
	//	m.bounds.center.z = 0.0;
	//	m.bounds.Expand(400.0f); // just expand to make sure we don't get culled

		m.bounds = new Bounds (new Vector3(0.0f,0.0f,0.0f), new Vector3(1.0f,1.0f,1.0f) * 400.0f);

		return m;
	}



	void recreateMesh () {
		GameObject tmp = gameObject;

		if (tmp.GetComponent<MeshFilter> ()) { DestroyImmediate (tmp.GetComponent<MeshFilter> ()); }

		MeshFilter meshFilter = (MeshFilter)tmp.AddComponent(typeof(MeshFilter));

		meshFilter.mesh = CreateSpriteMeshes(count);

		if (!tmp.GetComponent<MeshRenderer> ()) {
			MeshRenderer renderer = tmp.AddComponent(typeof(MeshRenderer)) as MeshRenderer;
			if(!tmp.GetComponent<MeshRenderer> ().sharedMaterial && !tmp.GetComponent<MeshRenderer> ().material) {
				if (renderer) {

					//Material mat = new Material(renderer.sharedMaterial);
					Material mat = new Material (Shader.Find ("Particles/Additive"));

					//mat.shader = Shader.Find ("Particles/Additive");
					Texture2D tex = new Texture2D (1, 1);
					//			tex.SetPixel (0, 0, Color.green);
					tex.SetPixel (0, 0, Color.yellow);
					tex.Apply ();
					mat.mainTexture = tex;
					mat.color = Color.green;
					//renderer.material.color = Color.yellow;

					renderer.sharedMaterial = mat;
				}
			}
		} 
	}

	void Awake() { 
//		recreateMesh(); 
	}
		
	void Update () { 
		if (
			o_count != count
		) {
		
			count = Mathf.Max (1, count);
			o_count = count;

			recreateMesh (); 
		}
	}

#endif

}
