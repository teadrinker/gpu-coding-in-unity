
using UnityEngine;
using System.Collections;


public class spCameraBound : MonoBehaviour {

	public float cameraMoveBoundRadius = 0.3f;
	public float cameraBoundEffectOffset = 0.2f;
	public GameObject cameraFolder;
	public GameObject cameraBoundEffect;
	public bool useCameraBound = true;
	public bool adjustCameraFolder = true;
	Vector3 cameraMoveBoundWorldOffset = Vector3.zero;

	void Start() {
		MeshFilter meshFilter = cameraBoundEffect.GetComponent<MeshFilter>();
		meshFilter.sharedMesh.bounds = new Bounds (Vector3.zero, Vector3.one * 9999.0f);
	}

	void Update() {
		Vector3 camPos = Camera.main.transform.position;
		Vector3 centerOfBound = gameObject.transform.position;

		Vector3 camPosAdjusted = camPos + cameraMoveBoundWorldOffset;
		float dist = Vector3.Distance(camPosAdjusted, centerOfBound);
		if( dist > cameraMoveBoundRadius ) {
			float penetration = dist - cameraMoveBoundRadius;
			Vector3 diffDir = camPosAdjusted - centerOfBound;
			diffDir.Normalize ();
			float boundScaleFactor = 2.0f * (cameraMoveBoundRadius + cameraBoundEffectOffset);
			cameraBoundEffect.SetActive(true);
			cameraBoundEffect.GetComponent<Renderer> ().material.SetFloat ("_Intensity", Mathf.Clamp(4.0f*penetration/boundScaleFactor, 0.0f, 3.0f));
			cameraBoundEffect.GetComponent<Renderer> ().material.SetVector ("_DeformDir", new Vector4(diffDir.x, diffDir.y, diffDir.z, penetration/boundScaleFactor));

			Vector3 worldOffset = Vector3.zero;
			if(adjustCameraFolder) {
				worldOffset = Mathf.Max(0.0f, penetration - cameraBoundEffectOffset*2.0f) * diffDir;
			}
			cameraFolder.transform.localPosition = centerOfBound - worldOffset;
			cameraBoundEffect.transform.localPosition = centerOfBound - worldOffset;
			cameraBoundEffect.transform.localScale = Vector3.one * boundScaleFactor;
			cameraMoveBoundWorldOffset = worldOffset;
		} else {
			cameraBoundEffect.SetActive(false);
			cameraFolder.transform.localPosition = centerOfBound;
		}		
	}
}